<?php 
// Silence speaks.