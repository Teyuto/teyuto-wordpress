<?php 
// Silence is golden.